package com.colegio.interfazGrafica.Controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import com.colegio.interfazGrafica.Entity.Curso;
import com.colegio.interfazGrafica.Repository.I_CursoRepository;


@Controller
public class ControllerCurso {
    @Autowired
    private I_CursoRepository cursoRepository;
    
    


    @GetMapping("/cursos")
    public String listaCursos(Model model) {
        List<Curso> cursos = cursoRepository.findAll();
        List<Object[]> alumnosPorCursos = cursoRepository.cantidadDeAlumnos();
        Curso curso = new Curso();
        model.addAttribute("cursoHtmlTabla", cursos);
        model.addAttribute("cursoGuardar",curso);
        model.addAttribute("alumnosPorCursos", alumnosPorCursos);
        return "cursos";
    }
     @PostMapping("/guardar")
     public String guardar(@ModelAttribute("cursoGuardar") Curso cr){
        cursoRepository.save(cr);
        return "redirect:cursos";
    }
    
    
    @RequestMapping("/")
    public String home(){
        return "home";
    }

    @DeleteMapping ("/borrar/{id}")
    public String borrar(@PathVariable Long id){
        cursoRepository.deleteById(id);
         return "redirect:cursos";

    }
    
 
        
        
    
   
    
}
