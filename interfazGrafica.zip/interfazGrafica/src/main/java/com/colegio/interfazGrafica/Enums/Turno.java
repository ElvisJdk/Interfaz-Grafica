package com.colegio.interfazGrafica.Enums;

public enum Turno {
    MAÑANA,
    TARDE,
    NOCHE
}
