package com.colegio.interfazGrafica;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InterfazGraficaApplicationTests {

	@Test
	void contextLoads() {
	}

}
